#!/usr/bin/env python3
"""
Point-in-time evaluation harness — AI in Finance & Economic Analysis (UPM).

A submission is a folder with a file `predict.py` that defines

    def predict(data: dict, as_of: pandas.Timestamp) -> pandas.DataFrame

`data` holds only information available at the close of `as_of`:
    prices, companies, corporate_actions, fundamentals, filings, analyst_reports,
    fx, macro, indices   (pandas DataFrames, same columns as the CSV/JSONL files)
The function returns one row per company with columns
    company_id, score          (higher score = higher expected return)   [required]
    weight                     (optional long-only portfolio weight, any scale)

Protocol (as in the course slides): the signal is computed with data up to the
close of `as_of`; trades execute at the OPEN of the next session of each
stock's exchange; costs cb = 5 bps on buys and cs = 2 bps on sells.
Target: total return (dividends and splits included) from that open to the open
21 sessions later.  Delisted stocks earn their delisting value.
Rebalancing dates: last NYSE session of each month in [--start, --end].

Students:   python evaluate.py --data ./train --submission ./my_model --start 2022-01 --end 2023-11
Instructor: python evaluate.py --data ./train ./eval --submission ./student_x --start 2023-12 --end 2025-11
"""
import argparse, importlib.util, json, os, sys, time, traceback
import numpy as np
import pandas as pd

H = 21
CB, CS = 0.0005, 0.0002


def load(dirs):
    def cat(fn, reader):
        parts = [reader(os.path.join(d, fn)) for d in dirs if os.path.exists(os.path.join(d, fn))]
        return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()
    csv = lambda p: pd.read_csv(p, dtype={"ticker": str}, low_memory=False)
    jl = lambda p: pd.read_json(p, lines=True, dtype=False)
    D = dict(prices=cat("prices_daily.csv", csv), companies=cat("companies.csv", csv),
             corporate_actions=cat("corporate_actions.csv", csv), fundamentals=cat("fundamentals.csv", csv),
             filings=cat("filings_text.jsonl", jl), analyst_reports=cat("analyst_reports.jsonl", jl),
             fx=cat("fx_daily.csv", csv), macro=cat("macro_daily.csv", csv), indices=cat("indices_daily.csv", csv))
    for k, col in [("prices", "date"), ("corporate_actions", "date"), ("fundamentals", "filing_date"),
                   ("filings", "filing_date"), ("analyst_reports", "date"), ("fx", "date"), ("macro", "date"),
                   ("indices", "date")]:
        D[k][col] = pd.to_datetime(D[k][col])
    for col in ("period_end",):
        D["fundamentals"][col] = pd.to_datetime(D["fundamentals"][col])
    c = D["companies"]
    c["listing_date"] = pd.to_datetime(c["listing_date"]); c["delisting_date"] = pd.to_datetime(c["delisting_date"])
    # a company may appear in both train and eval files: keep one row, latest delisting info
    agg = c.groupby("company_id").agg(listing_date=("listing_date", "min"), delisting_date=("delisting_date", "max"),
                                      delisting_reason=("delisting_reason", "last"))
    static = c.drop(columns=["listing_date", "delisting_date", "delisting_reason"]).drop_duplicates("company_id")
    D["companies"] = static.merge(agg.reset_index(), on="company_id")
    D["prices"] = D["prices"].sort_values(["company_id", "date"]).reset_index(drop=True)
    D["fx"] = D["fx"].drop_duplicates("date").sort_values("date")
    return D


def point_in_time(D, as_of):
    v = {}
    v["prices"] = D["prices"][D["prices"].date <= as_of]
    v["corporate_actions"] = D["corporate_actions"][D["corporate_actions"].date <= as_of]
    v["fundamentals"] = D["fundamentals"][D["fundamentals"].filing_date <= as_of]
    v["filings"] = D["filings"][D["filings"].filing_date <= as_of]
    v["analyst_reports"] = D["analyst_reports"][D["analyst_reports"].date <= as_of]
    for k in ("fx", "macro", "indices"):
        v[k] = D[k][D[k].date <= as_of]
    c = D["companies"][D["companies"].listing_date <= as_of].copy()
    hide = c.delisting_date > as_of
    c.loc[hide, ["delisting_date", "delisting_reason"]] = [pd.NaT, None]
    v["companies"] = c
    return {k: x.copy() for k, x in v.items()}


def build_adjusted(D):
    """Total-return-adjusted OPEN and CLOSE series per company (dividends & splits at the open)."""
    p = D["prices"]
    ca = D["corporate_actions"]
    div = ca[ca.event_type == "dividend"].groupby(["company_id", "date"]).value.sum()
    spl = ca[ca.event_type == "split"].groupby(["company_id", "date"]).value.prod()
    idx = pd.MultiIndex.from_frame(p[["company_id", "date"]])
    d_ = div.reindex(idx).fillna(0).values
    s_ = spl.reindex(idx).fillna(1).values
    same = p.company_id.values[1:] == p.company_id.values[:-1]
    o, c = p.open.values, p.close.values
    go = np.ones(len(p)); gc = np.ones(len(p))
    go[1:] = np.where(same, (o[1:] * s_[1:] + d_[1:]) / o[:-1], 1.0)
    gc[1:] = np.where(same, (c[1:] * s_[1:] + d_[1:]) / c[:-1], 1.0)
    p = p.assign(A_open=np.exp(pd.Series(np.log(go)).groupby(p.company_id.values).cumsum().values),
                 A_close=np.exp(pd.Series(np.log(gc)).groupby(p.company_id.values).cumsum().values))
    # exact: A_close_t / A_open_t = close_t / open_t
    p["A_close"] = p.A_open * p.close / p.open
    return p


def targets(P, comp, as_of, fx):
    """Forward open-to-open total returns (local and USD) for stocks listed at as_of."""
    rows = []
    fx_t = fx.set_index("date")
    for cid, g in P.groupby("company_id", sort=False):
        dts = g.date.values
        k = np.searchsorted(dts, np.datetime64(as_of), side="right")      # first session after as_of
        if k == 0 or k >= len(g):
            continue
        if (np.datetime64(as_of) - dts[k - 1]) > np.timedelta64(7, "D"):
            continue
        if k + H < len(g):
            r = g.A_open.values[k + H] / g.A_open.values[k] - 1; t_exit = dts[k + H]
        elif pd.isna(comp.get(cid, pd.NaT)):
            # end of sample (not a delisting): accept a slightly shorter horizon at the very end
            if len(g) - 1 - k < 15:
                continue
            r = g.A_open.values[-1] / g.A_open.values[k] - 1; t_exit = dts[-1]
        else:
            # delisted within the holding period -> delisting value (last close)
            r = g.A_close.values[-1] / g.A_open.values[k] - 1; t_exit = dts[-1]
        rows.append((cid, g.exchange.values[0], dts[k], t_exit, r))
    t = pd.DataFrame(rows, columns=["company_id", "exchange", "entry", "exit", "ret_local"])
    ccy = t.exchange.map({"NYSE": "USD", "NASDAQ": "USD", "LSE": "GBP", "XETRA": "EUR", "BME": "EUR", "TSE": "JPY"})
    def usd_per(c, d):
        row = fx_t.iloc[fx_t.index.searchsorted(d, side="right") - 1]
        return {"USD": 1.0, "GBP": row.GBPUSD, "EUR": row.EURUSD, "JPY": 1 / row.USDJPY}[c]
    f0 = np.array([usd_per(c, d) for c, d in zip(ccy, t.entry)])
    f1 = np.array([usd_per(c, d) for c, d in zip(ccy, t.exit)])
    t["ret_usd"] = (1 + t.ret_local) * f1 / f0 - 1
    return t


def spearman(a, b):
    if len(a) < 5: return np.nan
    return pd.Series(a).rank().corr(pd.Series(b).rank())


def month_ends(prices, start, end):
    nyse = prices[prices.exchange == "NYSE"].date.drop_duplicates().sort_values()
    me = nyse.groupby(nyse.dt.to_period("M")).max()
    me = me[(me.index >= pd.Period(start)) & (me.index <= pd.Period(end))]
    return list(me.values)


def run(args):
    D = load(args.data)
    P = build_adjusted(D)
    comp_dl = D["companies"].set_index("company_id").delisting_date.to_dict()
    spec = importlib.util.spec_from_file_location("submission", os.path.join(args.submission, "predict.py"))
    mod = importlib.util.module_from_spec(spec)
    sys.path.insert(0, os.path.abspath(args.submission))
    spec.loader.exec_module(mod)
    dates = month_ends(D["prices"], args.start, args.end)
    print(f"{len(dates)} rebalancing dates: {pd.Timestamp(dates[0]).date()} .. {pd.Timestamp(dates[-1]).date()}")
    recs = []; port_prev = pd.Series(dtype=float); nav = [1.0]; bench = [1.0]
    per_date = []
    for as_of in dates:
        as_of = pd.Timestamp(as_of)
        view = point_in_time(D, as_of)
        t0 = time.time()
        try:
            out = mod.predict(view, as_of)
        except Exception:
            traceback.print_exc(); print(f"predict() failed at {as_of.date()}"); out = pd.DataFrame(columns=["company_id", "score"])
        dt = time.time() - t0
        tg = targets(P, comp_dl, as_of, D["fx"])
        m = tg.merge(out, on="company_id", how="left")
        cov = m.score.notna().mean() if len(m) else 0
        mm = m.dropna(subset=["score"])
        ic = spearman(mm.score.values, mm.ret_local.values)
        ic_x = np.nanmean([spearman(g.score.values, g.ret_local.values) for _, g in mm.groupby("exchange") if len(g) >= 8])
        q = pd.qcut(mm.score.rank(method="first"), 5, labels=False) if len(mm) >= 10 else None
        spread = mm.ret_local[q == 4].mean() - mm.ret_local[q == 0].mean() if q is not None else np.nan
        # portfolio (USD)
        if "weight" in mm and mm.weight.notna().any():
            w = mm.set_index("company_id").weight.clip(lower=0).fillna(0)
        else:
            w = pd.Series(1.0, index=mm.company_id[q == 4]) if q is not None else pd.Series(dtype=float)
        w = w / w.sum() if w.sum() > 0 else w
        allw = w.reindex(port_prev.index.union(w.index)).fillna(0)
        prev = port_prev.reindex(allw.index).fillna(0)
        buys = (allw - prev).clip(lower=0).sum(); sells = (prev - allw).clip(lower=0).sum()
        cost = CB * buys + CS * sells
        r_usd = tg.set_index("company_id").ret_usd
        gross = float((w * r_usd.reindex(w.index).fillna(0)).sum())
        net = (1 - cost) * (1 + gross) - 1
        bmk = float(r_usd.mean())
        # drift weights to the end of the holding period
        grown = w * (1 + r_usd.reindex(w.index).fillna(0))
        port_prev = grown / grown.sum() if grown.sum() > 0 else grown
        nav.append(nav[-1] * (1 + net)); bench.append(bench[-1] * (1 + bmk))
        per_date.append(dict(as_of=as_of.date(), n_universe=len(tg), coverage=round(cov, 3), ic=ic, ic_within_exchange=ic_x,
                             q5_minus_q1=spread, port_net_usd=net, bench_usd=bmk, turnover=buys, cost=cost, seconds=round(dt, 2)))
        print(f"{as_of.date()}  N={len(tg):4d} cov={cov:5.1%} IC={ic:+.3f} ICx={ic_x:+.3f} Q5-Q1={spread:+.3%} "
              f"port={net:+.2%} bench={bmk:+.2%} ({dt:.1f}s)")
    pdf = pd.DataFrame(per_date)
    ppy = 12
    def ann(x): return (1 + x).prod() ** (ppy / len(x)) - 1
    act = pdf.port_net_usd - pdf.bench_usd
    navs = pd.Series(nav)
    res = dict(
        submission=os.path.abspath(args.submission), n_dates=len(pdf), mean_coverage=pdf.coverage.mean(),
        mean_IC=pdf.ic.mean(), IC_tstat=pdf.ic.mean() / (pdf.ic.std() / np.sqrt(len(pdf))), IC_hit_rate=(pdf.ic > 0).mean(),
        mean_IC_within_exchange=pdf.ic_within_exchange.mean(),
        q5_minus_q1_monthly=pdf.q5_minus_q1.mean(),
        portfolio_ann_return_usd=ann(pdf.port_net_usd), portfolio_ann_vol=pdf.port_net_usd.std() * np.sqrt(ppy),
        portfolio_sharpe=pdf.port_net_usd.mean() / pdf.port_net_usd.std() * np.sqrt(ppy),
        portfolio_max_drawdown=float((navs / navs.cummax() - 1).min()),
        benchmark_ann_return_usd=ann(pdf.bench_usd),
        information_ratio=act.mean() / act.std() * np.sqrt(ppy), mean_turnover=pdf.turnover.mean())
    print("\n=== SUMMARY ===")
    for k, v in res.items():
        print(f"{k:28s} {v:.4f}" if isinstance(v, float) else f"{k:28s} {v}")
    if args.out:
        os.makedirs(args.out, exist_ok=True)
        pdf.to_csv(os.path.join(args.out, "per_date.csv"), index=False)
        json.dump(res, open(os.path.join(args.out, "summary.json"), "w"), indent=1, default=float)
    return res


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data", nargs="+", required=True, help="one or more dataset folders (train [eval])")
    ap.add_argument("--submission", required=True, help="folder containing predict.py")
    ap.add_argument("--start", required=True, help="first rebalancing month, e.g. 2022-01")
    ap.add_argument("--end", required=True, help="last rebalancing month, e.g. 2023-11")
    ap.add_argument("--out", default=None, help="folder for per_date.csv and summary.json")
    run(ap.parse_args())
