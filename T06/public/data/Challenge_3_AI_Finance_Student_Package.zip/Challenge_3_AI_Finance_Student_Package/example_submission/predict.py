"""Example submission: 12-1 month price momentum (a simple, beatable baseline).

The evaluator imports this file and calls predict(data, as_of) once per rebalancing date.
`data` only contains information available at the close of `as_of` (point-in-time).
You may load pre-trained model files stored in this same folder, e.g.
    MODEL = joblib.load(os.path.join(os.path.dirname(__file__), "model.pkl"))
"""
import os, sys
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from fin_utils import total_return_index


def predict(data, as_of):
    p = total_return_index(data["prices"], data["corporate_actions"])
    # universe: companies that traded in the last week
    last = p.groupby("company_id").date.max()
    universe = last[last >= as_of - pd.Timedelta(days=7)].index
    p = p[p.company_id.isin(universe)].groupby("company_id").tail(260)

    def mom(g):
        t = g.tri.values
        return np.log(t[-22] / t[-253]) if len(t) >= 253 else np.nan

    score = p.groupby("company_id").apply(mom, include_groups=False)
    score = score.reindex(universe).fillna(0.0)
    return pd.DataFrame({"company_id": score.index, "score": score.values})
