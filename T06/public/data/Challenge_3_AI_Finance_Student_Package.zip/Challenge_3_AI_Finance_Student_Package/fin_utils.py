"""Helper functions for the AI in Finance synthetic dataset (UPM).

    from fin_utils import load_dataset, total_return_index
    data = load_dataset("train")
    tri = total_return_index(data["prices"], data["corporate_actions"])
"""
import os
import numpy as np
import pandas as pd


def load_dataset(folder):
    """Load every table of a dataset folder into a dict of DataFrames (dates parsed)."""
    f = lambda n: os.path.join(folder, n)
    d = dict(prices=pd.read_csv(f("prices_daily.csv"), parse_dates=["date"], dtype={"ticker": str}),
             companies=pd.read_csv(f("companies.csv"), parse_dates=["listing_date", "delisting_date"], dtype={"ticker": str}),
             corporate_actions=pd.read_csv(f("corporate_actions.csv"), parse_dates=["date"]),
             fundamentals=pd.read_csv(f("fundamentals.csv"), parse_dates=["period_end", "filing_date"]),
             filings=pd.read_json(f("filings_text.jsonl"), lines=True, dtype=False),
             analyst_reports=pd.read_json(f("analyst_reports.jsonl"), lines=True, dtype=False),
             fx=pd.read_csv(f("fx_daily.csv"), parse_dates=["date"]),
             macro=pd.read_csv(f("macro_daily.csv"), parse_dates=["date"]),
             indices=pd.read_csv(f("indices_daily.csv"), parse_dates=["date"]))
    d["filings"]["filing_date"] = pd.to_datetime(d["filings"]["filing_date"])
    d["analyst_reports"]["date"] = pd.to_datetime(d["analyst_reports"]["date"])
    return d


def total_return_index(prices, corporate_actions, field="close"):
    """Split- and dividend-adjusted total-return index per company, built FORWARD in time
    (no look-ahead: the value at t only uses information up to t).  Returns a copy of
    `prices` with an extra column `tri` and the daily total return `ret`."""
    p = prices.sort_values(["company_id", "date"]).reset_index(drop=True)
    ca = corporate_actions
    div = ca[ca.event_type == "dividend"].groupby(["company_id", "date"]).value.sum()
    spl = ca[ca.event_type == "split"].groupby(["company_id", "date"]).value.prod()
    idx = pd.MultiIndex.from_frame(p[["company_id", "date"]])
    dv = div.reindex(idx).fillna(0).values
    sp = spl.reindex(idx).fillna(1).values
    x = p[field].values
    same = np.r_[False, p.company_id.values[1:] == p.company_id.values[:-1]]
    prev = np.r_[np.nan, x[:-1]]
    gross = np.where(same, (x * sp + dv) / prev, 1.0)
    p["ret"] = np.where(same, gross - 1, np.nan)
    p["tri"] = np.exp(pd.Series(np.log(gross)).groupby(p.company_id.values).cumsum().values)
    return p
